
# Prompt Portfolio – NeuroKit2

## 📌 Prompt 1: Implement Asynchronous Signal Processing Support

### Context
NeuroKit2 currently processes signals synchronously. The core pipeline function `nk.bio_process()` orchestrates calls to signal-specific functions (e.g., `ecg_process`, `eda_process`) in a blocking manner.

### Technical Rationale
Adding asynchronous processing support can improve scalability for large datasets and real-time applications. This is critical for research labs using streaming data or multiple signals in parallel.

### Implementation Scope
- Refactor `bio_process()` to support `async def` and `await` keyword.
- Update internal signal-specific process functions to optionally support asynchronous execution.
- Add an example Jupyter notebook showing real-time simulation use.

### Success Metrics
- Able to process multiple signals in parallel without blocking.
- Real-time signal stream (simulated) processed at <50ms delay per segment.
- All existing synchronous use cases still work.

### Integration Points
- `neurokit2/bio/bio_process.py`
- Signal-specific modules: `ecg/ecg_process.py`, `eda/eda_process.py`, etc.

---

## 📌 Prompt 2: Add CLI Interface for Batch Processing

### Context
NeuroKit2 only supports Python-based usage. There's no CLI for non-programmers or automation.

### Technical Rationale
A CLI would make the tool accessible to non-coders and allow researchers to process datasets from terminal scripts or scheduled jobs.

### Implementation Scope
- Create a CLI wrapper using `argparse` or `click`.
- Support batch input from `.csv` or `.tsv` files.
- Allow output of processed features in a specified format (CSV, JSON).

### Success Metrics
- `neurokit2 process --input file.csv --output results.csv` processes all signals correctly.
- CLI covered by automated tests.

### Integration Points
- New module: `cli.py`
- Hook into `bio_process()` function.

---

## 📌 Prompt 3: Refactor Common Signal Utilities into Shared Module

### Context
Several signal preprocessing functions like normalization, filtering, and resampling are duplicated across signal modules.

### Technical Rationale
Consolidating these into a shared module improves maintainability and avoids inconsistencies in signal processing.

### Implementation Scope
- Create `neurokit2/shared/preprocessing_utils.py`.
- Move shared functions like `normalize`, `resample`, and `clean_signal`.
- Update references in `ecg`, `eda`, `rsp`, etc.

### Success Metrics
- All modules reference shared utilities without regression.
- Reduction of duplicated code by at least 25%.
- 100% unit test coverage on shared functions.

### Integration Points
- `ecg/ecg_clean.py`, `eda/eda_clean.py`, etc.
- New shared module in `neurokit2/shared`.

---

## 📌 Prompt 4: Improve Edge Case Testing for Signal Functions

### Context
Many signal functions (e.g., `ecg_peaks`, `eda_clean`) lack rigorous tests for edge cases like noisy inputs, short durations, or missing values.

### Technical Rationale
Improved test coverage will increase production-readiness and reduce bug risk when used with real-world data.

### Implementation Scope
- Write new tests for each signal function with:
  - Noisy signals
  - NaN/missing values
  - Very short signals
- Use `pytest.mark.parametrize` for input variety.

### Success Metrics
- 95%+ test coverage on signal modules.
- Test run duration under 5 seconds per module.
- CI passes with full coverage reports.

### Integration Points
- `tests/test_ecg.py`, `tests/test_eda.py`, etc.

---

## 📌 Prompt 5: Add Typed Function Signatures Across Codebase

### Context
Most NeuroKit2 functions lack Python 3 type hints, which hinders static analysis and IDE support.

### Technical Rationale
Adding type hints improves code readability, developer tooling (autocomplete, refactoring), and documentation clarity.

### Implementation Scope
- Add type hints to all functions in at least `bio_process.py`, `ecg_process.py`, and `eda_process.py`.
- Use `mypy` to validate static typing.

### Success Metrics
- `mypy` shows 0 errors in typed files.
- Functions are clearer to understand.
- Documented in CONTRIBUTING.md.

### Integration Points
- `neurokit2/bio/bio_process.py`, `ecg/ecg_process.py`, `eda/eda_process.py`.

---

## 🔢 Prompt Priority Ranking

| Rank | Prompt                                          | Reason for Priority                    |
|------|--------------------------------------------------|----------------------------------------|
| 1    | Async Signal Processing                         | High impact, real-time capability      |
| 2    | CLI Interface                                   | Accessibility and automation           |
| 3    | Shared Signal Utilities                         | Maintainability and DRY principle      |
| 4    | Edge Case Testing                               | Reliability and production readiness   |
| 5    | Type Hints                                      | Long-term maintainability              |

---

## ⚙️ Complexity Assessment

| Prompt                         | Complexity | Est. Time |
|--------------------------------|------------|-----------|
| Async Signal Processing        | High       | 2–3 days  |
| CLI Interface                  | Medium     | 1–2 days  |
| Shared Signal Utilities        | Medium     | 1–2 days  |
| Edge Case Testing              | Medium     | 1–2 days  |
| Type Hints                     | Low        | <1 day    |
